# Capping

## [v8.2.7](https://github.com/BigWigsMods/Capping/tree/v8.2.7) (2019-08-08)
[Full Changelog](https://github.com/BigWigsMods/Capping/compare/v8.2.6...v8.2.7)

- Wintergrasp: Add locale for towers.  
- Wintergrasp: Add bars for the tower health.  
- Alterac Valley: Add health check for Ivus/Lokholar.  
- Allow the countdown timer to show in scenarios (warfront/islands), closes #29  
