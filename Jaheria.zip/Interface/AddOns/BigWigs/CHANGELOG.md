# BigWigs

## [v163](https://github.com/BigWigsMods/BigWigs/tree/v163) (2019-08-08)
[Full Changelog](https://github.com/BigWigsMods/BigWigs/compare/v162...v163)

- EternalPalace/QueenAzshara: Fix Essence of Azeroth time.  
- bump version  
- EternalPalace/QueenAzshara: Improve the Essence of Azeroth warning  
- EternalPalace/AbyssalCommander: Add personal warning when on 3 or more stacks.  
- Plugins/BossBlock: Better method for hiding the objective tracker.  
- EternalPalace/AbyssalCommander: Add a counter to Overwhelming Barrage  
- EternalPalace/QueenAzshara: Add warnings for console debuffs and add a warning when standing in nether portals  
- EternalPalace/BlackwaterBehemoth: Mark Piercing Barb targets  
