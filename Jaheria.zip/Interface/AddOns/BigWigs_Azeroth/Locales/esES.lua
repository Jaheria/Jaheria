local L = BigWigs:NewBossLocale("Warbringer Yenajz", "esES") or BigWigs:NewBossLocale("Warbringer Yenajz", "esMX")
if not L then return end
if L then
	--L.tear = "You stood in a Reality Tear"
end
