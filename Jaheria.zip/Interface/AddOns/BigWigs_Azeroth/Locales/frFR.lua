local L = BigWigs:NewBossLocale("Warbringer Yenajz", "frFR")
if not L then return end
if L then
	L.tear = "Vous étiez dans une Brèche dans la réalité"
end
